define(
"dojo/cldr/nls/it/currency", //begin v1.x content
{
	"HKD_displayName": "Dollaro di Hong Kong",
	"CHF_displayName": "Franco Svizzero",
	"CAD_displayName": "Dollaro Canadese",
	"CNY_displayName": "Renmimbi Cinese",
	"USD_symbol": "US$",
	"AUD_displayName": "Dollaro Australiano",
	"JPY_displayName": "Yen Giapponese",
	"CAD_symbol": "CA$",
	"USD_displayName": "Dollaro Statunitense",
	"GBP_displayName": "Sterlina Inglese",
	"EUR_displayName": "Euro"
}
//end v1.x content
);